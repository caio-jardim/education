import streamlit as st
import database as db
import time

def show_login():
    st.title("🔒 Acesso ao Sistema")
    
    # Mantemos clear_on_submit=False no login. 
    # Motivo: Se o usuário errar a senha, ele não quer ter que digitar o usuário de novo.
    with st.form("login_form"):
        user = st.text_input("Usuário")
        password = st.text_input("Senha", type="password")
        submit = st.form_submit_button("Entrar")
        
        if submit:
            if not user or not password:
                st.warning("Preencha todos os campos.")
                return

            try:
                df_users = db.get_usuarios()
                if df_users.empty:
                    st.error("Erro Crítico: Tabela de usuários vazia.")
                    return

                # 1. Identifica os nomes corretos das colunas (Segurança)
                col_user = 'Username' if 'Username' in df_users.columns else 'username'
                col_pass = 'Password' if 'Password' in df_users.columns else 'password'

                # 2. Limpeza de dados (Trim) para evitar erro por espaço em branco
                user_input = user.strip()
                pass_input = password.strip()

                # 3. Filtro
                usuario_encontrado = df_users[
                    (df_users[col_user].astype(str).str.strip() == user_input) & 
                    (df_users[col_pass].astype(str).str.strip() == pass_input)
                ]
                
                if not usuario_encontrado.empty:
                    st.success("Login realizado!")
                    st.session_state['logado'] = True
                    # Salva os dados do usuário na sessão
                    st.session_state['usuario'] = usuario_encontrado.iloc[0].to_dict()
                    time.sleep(0.5) # Pequena pausa estética
                    st.rerun()
                else:
                    st.error("Usuário ou senha incorretos.")
            except Exception as e:
                st.error(f"Erro ao validar login: {e}")

def logout():
    st.session_state['logado'] = False
    st.session_state['usuario'] = None
    st.rerun()