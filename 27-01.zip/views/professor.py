import streamlit as st
import database as db
from datetime import date
from modules.ui import header_page, kpi_card

def show_professor(usuario, selected_page):
    # Recupera dados do professor logado
    try:
        df_professores = db.get_professores()
        # Filtra o ID vinculado ao usuário logado
        meus_dados = df_professores[df_professores['id_prof'].astype(str) == str(usuario['id_vinculo'])]
        
        if meus_dados.empty:
            st.error("⚠️ Seu usuário não está vinculado a nenhum professor no cadastro.")
            return

        nome_prof = meus_dados.iloc[0]['nome_professor']
        id_prof = usuario['id_vinculo']
        
    except Exception as e:
        st.error(f"Erro de conexão: {e}")
        return

    # --- NAVEGAÇÃO ---

    # 1. MEUS ALUNOS (Listagem)
    if selected_page == "Meus Alunos":
        header_page("Meus Alunos", f"Lista de alunos de {nome_prof}")
        
        try:
            # Tenta buscar vínculo. Se não tiver função pronta, buscamos alunos gerais
            # Idealmente: db.get_alunos_por_professor(id_prof)
            df_alunos = db.get_alunos() 
            
            # Mostra KPI simples
            kpi_card("Total de Alunos", str(len(df_alunos)), "alunos")
            st.write("")
            
            st.dataframe(
                df_alunos[['nome_aluno', 'serie', 'escola']], 
                use_container_width=True,
                hide_index=True
            )
        except Exception as e:
            st.error(f"Erro ao carregar alunos: {e}")

    # 2. MINHAS AULAS (Registro e Histórico)
    elif selected_page == "Minhas Aulas":
        header_page("Gestão de Aulas", "Lance novas aulas ou consulte o histórico")
        
        # Criamos tabs internas para organizar a ação
        tab_lancamento, tab_historico = st.tabs(["📝 Registrar Nova Aula", "📜 Histórico Completo"])
        
        # --- ABA 1: LANÇAR AULA ---
        with tab_lancamento:
            st.markdown("##### Preencha os dados da aula dada")
            with st.form("form_aula_prof", clear_on_submit=True):
                df_alunos = db.get_alunos()
                
                col1, col2 = st.columns(2)
                with col1:
                    # Selectbox de alunos
                    opcoes_alunos = df_alunos['nome_aluno'].unique() if not df_alunos.empty else []
                    nome_aluno_selecionado = st.selectbox("Selecione o Aluno", options=opcoes_alunos)
                    data_aula = st.date_input("Data da Aula", date.today())
                
                with col2:
                    duracao = st.number_input("Duração (Horas)", min_value=0.5, step=0.5, format="%.1f")
                    modalidade = st.selectbox("Modalidade", ["Education", "Online", "Casa"])
                
                obs = st.text_area("Resumo / Observações da aula")
                
                # Botão Full Width
                submitted = st.form_submit_button("✅ Confirmar Lançamento de Aula")
                
                if submitted:
                    # Lógica de salvamento
                    try:
                        filtro = df_alunos[df_alunos['nome_aluno'] == nome_aluno_selecionado]
                        if not filtro.empty:
                            id_aluno = filtro['id_aluno'].values[0]
                            data_str = data_aula.strftime("%d/%m/%Y")
                            
                            db.registrar_aula(
                                data_str, int(id_aluno), nome_aluno_selecionado, 
                                int(id_prof), nome_prof, modalidade, duracao, obs
                            )
                            st.success("🚀 Aula registrada com sucesso!")
                            st.balloons()
                        else:
                            st.error("Aluno não encontrado.")
                    except Exception as e:
                        st.error(f"Erro ao gravar: {e}")

        # --- ABA 2: HISTÓRICO ---
        with tab_historico:
            df_aulas = db.get_aulas()
            if not df_aulas.empty:
                # Filtrar apenas as aulas deste professor
                minhas_aulas = df_aulas[df_aulas['id_professor'].astype(str) == str(id_prof)]
                
                st.dataframe(
                    minhas_aulas, 
                    use_container_width=True, 
                    hide_index=True
                )
            else:
                st.info("Nenhuma aula registrada.")

    # 3. AGENDA (Placeholder)
    elif selected_page == "Agenda":
        header_page("Minha Agenda", "Próximas aulas agendadas")
        st.info("🚧 Funcionalidade de Agenda em desenvolvimento.")