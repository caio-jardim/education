import streamlit as st
import pandas as pd
import database as db
from modules import ui_alunos, ui_professores, ui_vendas, ui_financeiro 
# Importando componentes visuais do nosso novo módulo
from modules.ui import kpi_card, header_page

def show_admin(usuario, selected_page):
    # O nome do usuário já vem do app.py, não precisamos recalcular aqui, mas podemos usar se quiser
    
    # --- ROTEAMENTO PELO MENU LATERAL (Vindo do app.py) ---
    
    # 1. VISÃO GERAL (DASHBOARD)
    if selected_page == "Visão Geral":
        header_page("Visão Geral")
        
        try:
            # Carregando dados para os KPIs
            df_alunos = db.get_saldo_alunos() # Supondo que retorne todos os alunos
            df_financeiro = db.get_financeiro_geral() # Supondo que retorne movimentações
            
            # Cálculos (Simples manipulação de Pandas)
            total_alunos = len(df_alunos) if not df_alunos.empty else 0
            
            # Calculando caixa do mês atual
            caixa_mes = 0.00
            if not df_financeiro.empty:
                # Converter coluna Data se necessário e filtrar mês atual...
                # Por simplificação, vamos somar tudo que é entrada 'Pago'
                entradas = df_financeiro[
                    (df_financeiro['Tipo'] == 'Entrada') & 
                    (df_financeiro['Status'] == 'Pago')
                ]
                # Tratamento de erro caso a coluna Valor venha como string
                # (Assumindo que você tratará isso no db.py, mas prevenindo aqui)
                caixa_mes = entradas['Valor'].sum() if not entradas.empty else 0.00

            # Layout dos Cards
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                kpi_card("Alunos Ativos", str(total_alunos), "alunos")
            with c2:
                kpi_card("Receita Total", f"R$ {caixa_mes:,.2f}", "money")
            with c3:
                kpi_card("Aulas Hoje", "8", "aulas") # Mockado (pode criar lógica depois)
            with c4:
                kpi_card("Novas Vendas", "3", "vendas") # Mockado
            
            st.divider()
            
            # Área de Gráficos (Placeholder elegante)
            st.markdown("### 📈 Performance Recente")
            if not df_financeiro.empty:
                # Exemplo simples de gráfico
                st.bar_chart(df_financeiro, x="Data", y="Valor", color="Tipo")
            else:
                st.info("Sem dados financeiros para gerar gráficos.")

        except Exception as e:
            st.error(f"Erro ao carregar dashboard: {e}")

    # 2. CADASTROS
    elif selected_page == "Cadastros":
        header_page("Cadastros")
        
        # Mantemos as tabs internas pois pertencem ao contexto "Cadastro"
        tab1, tab2 = st.tabs(["🎓 Novo Aluno", "👨‍🏫 Novo Professor"])
        
        with tab1:
            ui_alunos.form_novo_aluno()
            
        with tab2:
            ui_professores.form_novo_professor()

    # 3. VENDAS
    elif selected_page == "Vendas":
        header_page("Gestão de Vendas", "Renovação e venda de pacotes")
        ui_vendas.form_renovacao_pacote()

    # 4. FINANCEIRO
    elif selected_page == "Financeiro":
        header_page("Financeiro", "Fluxo de caixa detalhado")
        ui_financeiro.show_financeiro()

    # 5. AULAS (HISTÓRICO)
    elif selected_page == "Aulas": # Atenção: No app.py definimos "Aulas", verifique o nome exato
        header_page("Histórico de Aulas", "Registro geral da escola")
        df_aulas = db.get_aulas()
        
        if not df_aulas.empty:
            st.dataframe(
                df_aulas, 
                use_container_width=True,
                hide_index=True
            )
        else:
            st.info("Nenhuma aula registrada até o momento.")