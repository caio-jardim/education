import streamlit as st

def load_css():
    # ADICIONE encoding="utf-8" DENTRO DO OPEN
    with open("assets/style.css", encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def kpi_card(titulo, valor, icone_nome):
    # ... (o resto do código continua igual) ...
    # Mapeamento simples de ícones para teste
    icones = {
        "vendas": "🏷️", 
        "alunos": "👤",
        "aulas": "📅",
        "money": "💲"
    }
    
    icon_str = icones.get(icone_nome, "")
    
    html_code = f"""
    <div class="kpi-card">
        <div class="kpi-icon">{icon_str}</div>
        <div class="kpi-title">{titulo}</div>
        <div class="kpi-value">{valor}</div>
    </div>
    """
    st.markdown(html_code, unsafe_allow_html=True)

def header_page(titulo, subheader=None):
    st.markdown(f"""
        <h1 style='color: #1A1A1A; font-size: 32px; margin-bottom: 0px;'>{titulo}</h1>
        <p style='color: #888; font-size: 16px; margin-top: 5px;'>{subheader if subheader else ''}</p>
        <hr style='margin-top: 10px; margin-bottom: 30px; border-top: 1px solid #ddd;'>
    """, unsafe_allow_html=True)